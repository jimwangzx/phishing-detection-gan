"""
-------------------------------------------------
   File Name:    test_Blocks.py
   Author:       Zhonghao Huang
   Date:         2019/10/17
   Description:
-------------------------------------------------
"""

from unittest import TestCase


class TestGMapping(TestCase):
    def setUp(self) -> None:
        pass

    def test_forward(self):
        pass

    def tearDown(self) -> None:
        pass
